package Pojo;

public class Login {
	
	
		
		private String lemail;
		public String getLemail() {
			return lemail;
		}
		public void setLemail(String lemail) {
			this.lemail = lemail;
		}
		public String getLpassword() {
			return lpassword;
		}
		public void setLpassword(String lpassword) {
			this.lpassword = lpassword;
		}
		public String lpassword;
		

}
