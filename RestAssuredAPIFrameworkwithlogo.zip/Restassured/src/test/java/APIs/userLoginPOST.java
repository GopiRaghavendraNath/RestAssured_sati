package APIs;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Common.Headers;
import Datamodel.Createcustomer;
import Datamodel.Logincustomer;
import Utili.PropertiesReader;
import Utili.Reporting;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import APIs.userCreationPOST;


public class userLoginPOST extends PropertiesReader {
	
	Reporting rep = new Reporting();
	
	//@Test(dependsOnGroups={"userCreationPOST.CreatePOST"})
	@Test
	
	
	public void LoginUserPOST() throws IOException {
		RequestSpecification res;
		ResponseSpecification resspec;
		Response response;
		Logincustomer data = new Logincustomer();
		PropertiesReader Global = new PropertiesReader();
		Headers head = new Headers();
		
		rep.logger = rep.extent.createTest("logsGeneration");
        rep.logger.log(Status.INFO,"createTest() method will return the ExtentTest object");
        System.out.println("logger value is"+rep.logger);
		
		rep.logger.log(Status.INFO, "This test case USer login post has been passed successfully");
		res = given().log().all().spec(requestSpecification()).headers(head.UserLoginHeaders())
				.body(data.logs("lemail", "lpassword"));

		resspec = new ResponseSpecBuilder().expectStatusCode(400).expectContentType(ContentType.JSON).build();
		response = res.when().post(Global.getGlobalvalue("loginuser")).then().log().all().spec(resspec).extract()
				.response();

		assertEquals(response.getStatusCode(), 400);

	}
}
